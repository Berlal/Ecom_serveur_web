<form method="POST" action="">
    <input type="text" name="first_name" placeholder="Prénom" required><br>
    <input type="text" name="last_name" placeholder="Nom" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <textarea name="message" placeholder="Message" required></textarea><br>
    <button type="submit">Envoyer</button>
</form>
