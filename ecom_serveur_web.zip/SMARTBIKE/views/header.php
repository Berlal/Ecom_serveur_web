<header>
    <div class="logo">
        <img src="assets/images/logo.png" alt="Smartbike Logo">
    </div>
    <nav>
        <ul>
            <li><a href="?page=home">Home</a></li>
            <li><a href="?page=products">Vélos</a></li>
            <li><a href="?page=contact">Contact</a></li>
        </ul>
    </nav>
</header>

<link rel="stylesheet" href="../assets/css/style.css">
<script src="../assets/js/main.js"></script>
